# FracTAL_ResUNet
Pytorch addaption of waldnerfs FracTAL_ResUNet repository that can be used for Field Delineation
Added Jordi
